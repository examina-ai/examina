# Examina — Förhör & Studierum

Mörk premium webbapp för svensk skola — **Exam Generator & Grader** + **AI Study Partner**.

- **Förhör & Rättning:** Källtext → genererar Sant/Falskt / Flerval / Långsvar med Max Grade (E-A), rättar mot Lgr22/Gy11.
- **Studierum:** Text/bild → sammanfattning, flip-flashcards, micro-quiz, Q&A-chatt.
- **Admin Panel:** Endast för admins/Owner. Hantera konton, se live-närvaro, handlednings-vy med tydligt samtycke, kick/ban, audit-logg.
- **Elev-login:** Ingen e-post krävs. Owner-konto: `Chef / Chef130901@`
- **Design:** Mörk, mobil + desktop-optimerad, fungerar offline i preview.

## Genvägar
- Adminpanel: `Ctrl+Shift+Ö` (endast inloggad som admin/Owner)
- Live URL (E2B preview): `https://8000-irjs1hmnrmik0r7tuv5rh.e2b.app`

## Kör lokalt
```bash
python3 -m http.server 8000 --bind 0.0.0.0
# öppna http://localhost:8000
```

## Publicera till GitHub Pages
1. Skapa nytt tomt repo på GitHub, t.ex. `examina-studium`
2. I denna mapp:
```bash
git init
git add index.html README.md
git commit -m "Initial: Examina v1.4"
git branch -M main
git remote add origin https://github.com/<ditt-användarnamn>/examina-studium.git
git push -u origin main
```
3. På GitHub: Settings → Pages → Source: `main` / `root` → Save. Din sida blir:
`https://<användarnamn>.github.io/examina-studium/`

> Alla konto-data sparas i `localStorage` (demo). Byt till riktig backend för produktion.

© 2026 Examina Studierum — Västerås
